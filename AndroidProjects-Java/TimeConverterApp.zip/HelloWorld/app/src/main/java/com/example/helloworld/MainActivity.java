package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void convertButtonFunction(View view) {

         // variables for inputs and output destination
        EditText minutes = findViewById(R.id.inputMinute);
        String input = minutes.getText().toString();
        EditText output = findViewById(R.id.outputSeconds);

        // throws exception for inputs that aren't numbers
        try {
            int min = Integer.parseInt(input);
            int seconds= min * 60;
            output.setText(seconds + " seconds.");
        } catch (NumberFormatException e){
            output.setText("Error");
        }
    }
}